close all;
clear all;
clc;

%% Open image
name = "person6";
A = imread(name,"jpg");  % read the image 
imshow(A);               % show the image as original
title('Original image')

